Index

  1. Getting Started
  2. Starting the programs
  2.1 Building a network.
  2.2. Forwarder parameters
  2.3. Sender parameters
  3. Compiling

1. Getting Started

This POC alles to emulate networks where every hop performs so called
"Latency Based Forwarding" (LBF queueing on outgoing interfaces. With LBF,
every packet carries a lmin and lmax parameter which indicate the
end-to-end minimum and maximum forwarding latency desired by the packet.

lmin and lmax are inclusive of the link propagation and the outgoing
interfaces queue latencies. lmin allows to "slow down" packets along
the path in the LBF queues of each node, lmax allows to differentiate
the priority packet will have being sent from the LBF queue when
it is congested.

For more implementation details. pls. refer to DESIGN.txt.


2. Starting the programs

2.1 Building a network.

How to start multiple instances of forwarder and sender together to
create a running test run is best understood by 

2.2. Forwarder parameters

usage: udpf -i <port>:<hdelay>,...                            (list of ports)
            -o <index>:<nh-port>:<odelay>:[:nosend],...       (list of ports)
            -f <dest-addr>:<oif-index>:<todelay>:<tohops>,... (list of destination routes)
           [-c <core-id-start>]                               (first CPU core to use)
            -r <runtime>                                      (stop after runtime seconds)
            -x <exp-id>                                       (experiment ID for logfile names)
            -w <fwd-id>                                       (ID of forwarder for logfile names)
           [-D]                                               (use dynamic prio LBF queuing algo)

Each instance of udpf is a forwarder for packets with one or more incoming
interfaces and one or more outgoing interfaces.

The parameter of the "-i" option defines all  incoming interfaces. Each
interface is identified by a UDP <port> number which needs to be unique
across all incoming interfaces of all forwarders running on the system.

The only parameter for an interface is the <hdelay> ([usec]), which is the delay of
the link into this incoming interface. It is added to the e_delay of 
packets received on this interface(port). A single incoming interface can receive
packet from an arbitrary number of senders or forwarders. There is no other
function of an incoming interface other than having a separate <hdelay> and
a separate CPU core for processing packets received on it.

The parameter of the "-o" option defines all outgoing interfaces. Each
interface is identified by an <index> that needs to be unique across all
outgoing interfaces of the forwarder. The first interface should use 0,
the next 1 and so on. The interface numbers are used in the FIB entries
(see below). <nh-port> is the UDP port number of the next-hop forwarders
incoming interface. If an outgoing interface is meant to be the last-hop
interface towards receiver(s), the "nosend" option should be used to inhibit
generation of packet from the interface because there is (currently) no
receiver application: Whether an interface sends packets or not, the same 
information about each packet that should be or is sent to the interface
is logged. Therefore there is no need to actually have a receiver to
measure LBF queuing behavior.

<odelay> allows for the outgoing interface to run <odelay> usec in the past.
Delaying all packets dequeued from the LBF queue allows to deal with
unavoidable linux scheduling delays. Initially, this parameter should be
configured to be 0. When a test run is performed, the log of the incoming
interfaces will show packets dropped by the incoming interface thread
of the forwarder because of linux scheduling delays (LINUXLATE). Then
the <odelay> parameter can be increased to compensate for the longest
delays seen. Typically, an <odelay> of 1 msec for a single hop is
sufficient. If N routers are along a pah, each routers <odelay> needs
to be suficiently larger than the odelay of the prior hop router, such
as 1 msec per hop. LINUXLATE packets are simply discarded, so depending
on the goal of a test run it may or may not be important to fix these
issues. When only the impact of minimum latency is to be analysed,
a few discarded packets are irrelevant. When the behavior of LBF
queue buildup is to be analyzed, a few discarded packets may be relevant.

The parameters to the "-f" option define all forwarding table (FIB) entries.
Each FB entry consists of a destination IP address <dest-addr>, the next-hop
outgoing interface <oif-index> and the LBF control parameters for this
destination: The <todelay> to the destination ([usec]) and the number
<tohops> of forwarder hops to the destination. When this forwarder is the
last hop to the destination, <tohops> is 1.

"-c" is optional and asks the forwarder to assign every input and output
thread it creates to a different core. the argument to "-c" is the starting
for the first thread created, and then the next thread adds "+2" for the
next core (assuming hyperthreading, skipping the hyperthread).

The interface speed is currently fixed at 100 Mbps. This is the fastest
speed where it was obvious that CPUs would be fast enough to support
real-time throughput with sending/receiving packets in real-time via
simple UDP/IP sockets.  Sending and receiving packets can take a few
usec of system call overhead (independent of packet size). Real-time operations,
might then already become an accuracy issue.

2.3. Sender parameters

usage: udps -p <port>                                 (forwarder input interface)
       -i <sender-string>                             (name field in packet)
       -d <dest-addr>                                 (IP dest address)
       -e <E_DELAY> -m <MIN DELAY> -M <MAX DELAY>     (edelay,lmin,lmax)
       -b <bps>                                       (flow bitrate)
      [-s <pkt-size>]                                 (packet size  )
      [-t <burst-int-usec>:<burst-usec>:<burst-bps>]  (burst parameters)
       -r <runtime-sec>                               (how long to send)

The sender will send packets to the local host UDP port <port>, which
must be the UDP port of the desired interface of the "udpf" forwarder
that this sender needs to send to.

The <sender-string> is the constant prefix for the string parameter 
in each packet. The sender appends an ASCII number for each packet.
For example, '-i f1p' would result in packets of the flow to have
name strings f1p1, f1p2, f1p3... ("flow 1, packet <n>").

<dest-addr> is the IP destination address. It must be configured in
the udpf forwarders so that packets will routed through the network.

The flow bitrate is just for the packetsize <pkt-size>. This packet
size is inclusive of all headers emulated.

If '-t' is specified, the flow will periodically, every <burst-int-usec>
start sending for <burst-usec> with a rate of <burst-bps> to then
return to <bps>.

"-r <runtime>" is the time the sender will run.

3. Compiling

Go to the "src" directory, run "./makescript". This will compile
the source and put the binaries into the "bin" directory.
