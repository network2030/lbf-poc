How to run this test
====================

./usecase_jitter_reduction.sh

You must have compiles the forwarder (udpf) and sender (udps) in ../../bin
in before starting this script.

The script starts in sequence four test runs.

The first test run shows how jitter introduced on one hop stays constant
across further hop if the traffic flow under test is best effort

The second test run shows up the jitter reduces hop by hop when the
test flow uses LBF with minimum latency (slo-lb) to allow each routers
queue to manage prioriting the LBF packet when it is late.

The third test run shows jitter adding up from congestiona cross four hops
with best effort.

Tests 4 .. 6 show how jitter aggregates much less or even reduces over
hop in the same setup  as the third test.

Prebaked results
================

results.txt contains the output of a test run of ./usecase_jitter_reduction.sh
in case you can not / want not run it yourself (or for verification that
your compiled binaries operate correctly).


Detailled Explanations
======================

This test script measures the effect of multi-hop jitter reduction based on
a minimum latency SLO paramter that causes packets to be intentionally lingering
in LBF router queues - UNLESS they had previously been unintentionally delayd
by congestion:

Whenever a packet gets unintentionally delayed due to congestion on a hop,
its observed latency on the following hop(s) will be larger than that of
non-congestion delayed packets. This longer latency will decrease the
lingering time calculated for the hop. This reduced lingering time will
cause the target time for the packet to be forwarded by the node to be
earlier than if it was not delayed by a prior hop. Ultimately, the
packet will catch up, even if it is subject to new congestion on this hop.

Test case topology:


             S2->R2     S3->R3     S4->R4    S5->R1
               |          |          |          |
               |          |          |          |
               |          |          |          |
          5100 v     5200 v     5300 v     5400 v
  S1->R1 ---> FWD1 ----> FWD2 ----> FWD3 ----> FWD4 ----> R1
                 Q1       | Q2       | Q3       | Q4
                          v          v          v
                         (FW)      (FW)        R4
                          |          |
                          v          v
                         (FW)       R3
                          |
                          v
                          R2


Four emulated forwarders FWD1, ... FWD4. Each forwarder
has an outgoing LBF queue Q1, ... Q4 where the effect of the test is observed.

The flow under test is S1->R1 injected into FWD1 and routed across
FWD1, FWD2, FWD3 and finally FWD4 which exits via Q4 (towards R1).

S2->R2, S3->R3, S4->R4 and S5->R1 are competing flows to create
congestion. S2->R2 creates congestion on Q1, S3->R3 on Q2 and so on.

Every queue has a new competing flow injected into it, because the
prior hop queue will have eliminated congestion between S1->R1
and that prior queues competing flow by serializing them on
the prior outgoing interface. Those two flows alone would therefore
not create congestion between themselves on a following hop (in the
absence of other competing traffic). 

To ensure that each queues new competing flow can eqully compete
against S1->R1, it is neessary that the prior hops competing flow
is removed first. This is done by setting up the routing tables
on the forwarders, such that that prior hop competing flow is
forward out to a different interface. S2->R2 is the old competing
flow on FWD2, so it is not forwarded out on Q2, but on a second
interface of FWD2 towards R2.

For flows to compete on equal terms against S1->R1, it is necessary
that they are also expected to have the same number of upcoming hops and
aggregate path propagation delay. Therefore the routing table setup
for R2 on FWD1 will indicate 3 more hops, FWD2 and two
further forwarders towards R2 and the same latency as for R1.

Additional forwarders 'FW' are not actually emulated and neither
are receivers. Only forwarders that impact the havior of queues that
are to be observed need to be emulated.

All flow have 5 hops with 100 usec physical propagation delay each on
each hop and 4 queue hops. To show some useful burst buildup, we should permit
 up to 100 usec queuing per hop: 500 (physical) + 400 (queuing) = 900 max





