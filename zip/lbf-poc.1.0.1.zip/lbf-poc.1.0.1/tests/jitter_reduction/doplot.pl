#!/usr/bin/perl

printf     "    packets   min  mean   max   [jitter]\n";
for ($i = 1; $i <= 4; $i++) {
    $f="UDPFWD-12-${i}-OIF-0";
    # print "$f\n";
    $fo="plot-${i}.plt";
    open(F, $f) || die "Can not read $f,";
    open(FO, ">$fo") || die "Can not write $fo,";
    $s=0;
    printf FO "# packet  t [usec] dt [usec]  edelay\n";

    $d_min = 9999; $d_max = $d_sum = $d_n = 0;
    while(<F>) {
	# print $_;
        chomp;
        ($sec, $nsec, $pkt, $sent, $ed, $edelay, $qd, $qdelay, $xxx) = split;
       	if (!$s) {
            $s = $sec;
	}
        $usec =~ s/://;
        $t = (($sec - $s) * 1000000000 + $nsec) / 1000;

	# print "$pkt\n";
        if($pkt =~ /f1/) {
	    $dt = $t - $tlast;
	    $delay = $edelay + $qdelay;
            printf FO "%8s %8d  %8d %8d\n", $pkt, $t, $dt, $delay;
	    $d_n++;
	    $d_sum += $delay;
	    if($delay < $d_min) {
	        $d_min = $delay;
	    }
	    if($delay > $d_max) {
	        $d_max = $delay;
	    }
	    $tlast = $t;
	}
    }
    printf FO "#SUM: packets: min/mean/max [range]: %6d: %4d %4d %4d [%3d]\n", $d_n, $d_min, $d_sum/$d_n, $d_max, $d_max - $d_min;
#plot-3.plt:#SUM: packets: min/mean/max [range]:  27000:  450  522  600 [150]
    printf     "Q%d:  %6d %5d %5d %5d   [  %4d]\n", $i, $d_n, $d_min, $d_sum/$d_n, $d_max, $d_max - $d_min;
    close(F);
    close(FO);
}
