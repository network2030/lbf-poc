#!/bin/bash

bin=../../bin
log=.
rt=10 # runtime 10 seconds

expid=12 # Unique experiment identifier in case multiple set of 

## Start forwarders through a script so we can easily add moree forwarders
## Assuming there are enough CPU cores. With four forwarders as preconfigured
## here, this is equivalent to:
##
## ../../bin/udpf -i 5100:100 -o 0:5200:0:,1:4000:0:nosend       -f 10.0.0.1:0:400:4,10.0.0.2:0:400:4                -c  2 -r 12 -x 12  -w 1
## ../../bin/udpf -i 5200:100 -o 0:5300:0:,1:4000:0:nosend       -f 10.0.0.1:0:300:3,10.0.0.3:0:300:3,10.0.0.2:1:0:1 -c  8 -r 12 -x 12  -w 2
## ../../bin/udpf -i 5300:100 -o 0:5400:0:,1:4000:0:nosend       -f 10.0.0.1:0:200:2,10.0.0.4:0:200:2,10.0.0.3:1:0:1 -c 14 -r 12 -x 12  -w 3
## ../../bin/udpf -i 5400:100 -o 0:5500:0:nosend,1:4000:0:nosend -f 10.0.0.1:0:100:1,10.0.0.5:0:100:1,10.0.0.4:1:0:1 -c 20 -r 12 -x 12  -w 4

forwarders() {
    # need to run forwarders 2 seconds longer to forward all packets (senders start 2 seconds later)
    rtf=`expr $rt + 2`
    # number of the forwarder
    f=1
    n=4
    nosend=""
    while [ $f -le $n ] ; do

        next=`expr $f + 1`

        if [ $f -eq $n ] ; then
            nosend="nosend"
        fi

	# Both R1=10.0.0.1 and R(f+1) go out same interface, same hops
	# This is the traffic whose congestion we want to measure
        hops=`expr $n - $f + 1`
        delay=`expr $hops \* 100`
	route_r1="10.0.0.1:0:${delay}:${hops}"
	route_next="10.0.0.${next}:0:${delay}:${hops}"

	# On FWD2... forward/discard R(f) to second outgoing interface
        # No need to calculate correct delay/hops, because that
	# traffic is just meant to be discard, not measured.
	route_prev=""
	if [ $f -gt 1 ] ; then
	    route_prev=",10.0.0.${f}:1:0:1"
	fi

	core=`expr 6 \* $f - 4`
	odelay=`expr $f \* 1000`

        cmd="${bin}/udpf -i 5${f}00:100 -o 0:5${next}00:${odelay}:${nosend},1:4000:${odelay}:nosend \
       	    -f ${route_r1},${route_next}${route_prev} -c ${core} -r ${rtf} -x ${expid}  -w ${f}"
        # echo "$cmd"
	$cmd > ${log}/UDPFWD-$expid-${f}-MAIN 2>&1 &
	f=`expr $f + 1`
    done
}

cat << EXPLANATION1

Use case: multi-hop congestion management with LBF
==================================================

EXPLANATION1

# burst=" -t 1000000:100:90000000 "
# b1="90000000"
brst1=" -t 10000:1000:55000000 "
brst2=" -t 10000:1000:57000000 "
brst3=" -t 10000:1000:57000000 "
brst4=" -t 10000:1000:59000000 "
brst5=" -t 10000:1000:70000000 "
b1="1000000"

###
### Test run 1 --------------------------------------------------------------------------------------------------------------------
###

echo -------
echo Test 1: Flow F1 best effort, only competing with flow F2 best effort
echo

echo -n "Starting Forwarders and Senders ..."
rm -f plot*plt UDP*
forwarders
read sec nsec < /proc/uptime # help to start forwarders synchronized
taskset -c 26 ${bin}/udps -S $sec -p 5100 -i f1p -d 10.0.0.1 -e 0 $brst1  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-1.log 2>&1 &
taskset -c 28 ${bin}/udps -S $sec -p 5100 -i f2p -d 10.0.0.2 -e 0 $brst2  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-2.log 2>&1 &

echo -n "Test running ..."

wait
echo Done
echo

./doplot.pl

echo
echo Result: jitter introduced by F2 on Q1, no change in jitter on later hops
echo

###
### Test run 2 --------------------------------------------------------------------------------------------------------------------
###

echo -------
echo Test 2: Flow F1 LBF slo-lb: 700 usec, competing with flow F2 best effort
echo

echo -n "Starting Forwarders and Senders ..."
rm -f plot*plt UDP*
forwarders
read sec nsec < /proc/uptime # help to start forwarders synchronized
taskset -c 26 ${bin}/udps -S $sec -p 5100 -i f1p -d 10.0.0.1 -e 0 $brst1  -m 700 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-1.log 2>&1 &
taskset -c 28 ${bin}/udps -S $sec -p 5100 -i f2p -d 10.0.0.2 -e 0 $brst2  -m 0   -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-2.log 2>&1 &

echo -n "Test running ..."

wait
echo Done
echo

./doplot.pl

echo
echo Result: jitter introduced by F2 on Q1 reduces further on Q2, Q3, Q4
echo



###
### Test run 3 --------------------------------------------------------------------------------------------------------------------
###

echo -------
echo Test 3: Flow F1 best effort, competing with flow F2,F3,F4 best effort
echo

echo -n "Starting Forwarders and Senders ..."
rm -f plot*plt UDP*
forwarders
read sec nsec < /proc/uptime # help to start forwarders synchronized
taskset -c 26 ${bin}/udps -S $sec -p 5100 -i f1p -d 10.0.0.1 -e 0 $brst1  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-1.log 2>&1 &
taskset -c 28 ${bin}/udps -S $sec -p 5100 -i f2p -d 10.0.0.2 -e 0 $brst2  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-2.log 2>&1 &
taskset -c 30 ${bin}/udps -S $sec -p 5200 -i f3p -d 10.0.0.3 -e 0 $brst3  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-3.log 2>&1 &
taskset -c 32 ${bin}/udps -S $sec -p 5300 -i f4p -d 10.0.0.4 -e 0 $brst4  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-4.log 2>&1 &
taskset -c 34 ${bin}/udps -S $sec -p 5400 -i f5p -d 10.0.0.1 -e 0 $brst5  -m 0 -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-5.log 2>&1 &

echo -n "Test running ..."

wait
echo Done
echo

./doplot.pl

echo
echo Result: jitter introduced by F2,F3,F4,F5
echo increase total jitter of F1 on every queue
echo

###
### Test run 4..6 ----------------------------------------------------------------------------------------------------------------
###

test=4
for i in 700 900  1100; do

echo -------
echo Test ${test}: Flow F1 LBF slo-lb: ${i} usec, competing with flow F2,F3,F4 best effort
echo

echo -n "Starting Forwarders and Senders ..."
rm -f plot*plt UDP*
forwarders
read sec nsec < /proc/uptime # help to start forwarders synchronized
taskset -c 26 ${bin}/udps -S $sec -p 5100 -i f1p -d 10.0.0.1 -e 0 $brst1  -m ${i} -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-1.log 2>&1 &
taskset -c 28 ${bin}/udps -S $sec -p 5100 -i f2p -d 10.0.0.2 -e 0 $brst2  -m 0   -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-2.log 2>&1 &
taskset -c 30 ${bin}/udps -S $sec -p 5200 -i f3p -d 10.0.0.3 -e 0 $brst3  -m 0   -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-3.log 2>&1 &
taskset -c 32 ${bin}/udps -S $sec -p 5300 -i f4p -d 10.0.0.4 -e 0 $brst4  -m 0   -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-4.log 2>&1 &
taskset -c 34 ${bin}/udps -S $sec -p 5400 -i f5p -d 10.0.0.1 -e 0 $brst5  -m 0   -M 0 -b $b1 -r ${rt} > UDPSND-${expid}-5.log 2>&1 &

echo -n "Test running ..."

wait
echo Done
echo

./doplot.pl

echo
echo Result: jitter introduced by F2,F3,F4,F5 increase less
echo "than with F1 using smaller slo-lb (or best-effort slo-lb=0)"
echo

test=`expr $test + 1`

done



