/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include "pifo.h"
#include "stime.h"
#include "evlog.h"

#define LQB_RANGE 1

static struct hnode *create_hnode(unsigned short lqbudget)
{
    struct hnode *new_hnode;
    uint16_t mod;

    new_hnode = calloc(1, sizeof (struct hnode));
    // new_hnode = malloc(sizeof (struct hnode));
    if (new_hnode == NULL) {
        fprintf(stderr, "hnode allocation failed\n");
        return (NULL);
    }
    mod = lqbudget % LQB_RANGE;
    new_hnode->range_start = lqbudget - mod;
    new_hnode->range_end = new_hnode->range_start + LQB_RANGE;
    //fprintf(stderr, "allocated hnode for range %hu, %hu\n",
    //        new_hnode->range_start, new_hnode->range_end);
    return new_hnode;
}

static struct hnode *get_hnode(struct pifo_qhead *qh, unsigned long lqbudget)
{
    struct hnode *new_hnode, *curr_hnode, *prev_hnode;

    curr_hnode = prev_hnode = qh->hnode1;
    if (curr_hnode == NULL) {
        new_hnode = create_hnode(lqbudget);
        if (!new_hnode)
            return NULL;
        qh->hnode1 = new_hnode;
        return new_hnode;
    }
    while (1) {
        if (curr_hnode == NULL) {
            new_hnode = create_hnode(lqbudget);
            if (!new_hnode)
                return NULL;
            prev_hnode->next_hnode = new_hnode;
            return new_hnode;
        }
        if ((lqbudget >= curr_hnode->range_start) &&
            (lqbudget < curr_hnode->range_end)) {
            //fprintf(stderr, "using existing hnode\n");
            return curr_hnode;
        } else if (lqbudget < curr_hnode->range_start) {
            new_hnode = create_hnode(lqbudget);
            if (!new_hnode)
                return NULL;
            new_hnode->next_hnode = curr_hnode;
            if (curr_hnode == prev_hnode) {
                qh->hnode1 = new_hnode;
            } else {
                prev_hnode->next_hnode = new_hnode;
            }
            return new_hnode;
        }
        prev_hnode = curr_hnode;
        curr_hnode = curr_hnode->next_hnode;
    }
}

int pifo_enqueue(struct pifo_qhead *qh, char *realpkt, unsigned short lqbudget,
                 unsigned long tmin_sec, unsigned long tmin_usec,
                 unsigned long tmax_sec, unsigned long tmax_usec,
                 unsigned long trcv_sec, unsigned long trcv_usec)
{
    struct pnode *my_pnode, *prev_pnode, *curr_pnode;
    struct hnode *my_hnode;

    //fprintf(stderr, "pushing %hu\n", lqbudget);

    my_hnode = get_hnode(qh, lqbudget);
    if (my_hnode == NULL) {
        fprintf(stderr, "Failed to find pifo head for %hu\n", lqbudget);
        return (1);
    }

    my_pnode = calloc(1, sizeof (struct pnode));
    // my_pnode = malloc(sizeof (struct pnode));
    if (my_pnode == NULL) {
        fprintf(stderr, "pnode allocation failed\n");
        return (1);
    }
    my_pnode->tmin_sec = tmin_sec;
    my_pnode->tmin_usec = tmin_usec;
    my_pnode->tmax_sec = tmax_sec;
    my_pnode->tmax_usec = tmax_usec;
    my_pnode->trcv_sec = trcv_sec;
    my_pnode->trcv_usec = trcv_usec;
    my_pnode->realpkt = realpkt;

    if (my_hnode->pifo == NULL) {
        my_hnode->pifo = my_pnode;
    } else {
        prev_pnode = curr_pnode = my_hnode->pifo;
        while (1) {
            if (curr_pnode == NULL) {
                prev_pnode->next_pnode = my_pnode;
                break;
            }
            if (stime_isless(tmin_sec, tmin_usec, curr_pnode->tmin_sec, curr_pnode->tmin_usec)) {
                if (prev_pnode == curr_pnode)
                    my_hnode->pifo = my_pnode;
                else
                    prev_pnode->next_pnode = my_pnode;
                my_pnode->next_pnode = curr_pnode;
                break;
            }
            prev_pnode = curr_pnode;
            curr_pnode = curr_pnode->next_pnode;
        }
    }
    qh->packets++;
    return 0;
}

// DBF pifo is a linked list of hnodes:
//
// hnode1 -> hnode2 -> ... -> hnodeN
//
// The sort oder of the pnodes is priority, which in the current
// implementation is the lqbudget parameter.
//
// Each pnode has a pifo whose sort criteria is the earliest possible
// send time.
//
// The dequeue algorithm finds the first hnode where the first pifo node
// is sendable. Not sendable are packets who are expired (after maximum
// send time) or not ready to be sent.
//
// For this algorithm to work, expired nodes need to be purged. 
//    
// Because of linux scheduling, the dequeuing thread (oif_fn()) may be
// interrupted for a relatively long time (e.g.: 200 usec when a single
// packet sending time is 24 used). Compensating for this is a bit tricky:
// This scheuling system prohibits absolute real-time operations, because
// physcially, the dequeuing thread can never send the packet as early as
// it should have been sent. But because we keep the absolute send-time
// together with the simulated edelay in the packet, we can still send
// a packet later than it should have been sent without impacting the
// simulation results.
//
// To make this work, the dequeuing function needs to be more intelligent
// and support a time range for which to dequeue: t1 is the  first time
// at which the packet needs to be dequeable. This would be the last time
// the dequeue thread last tried dequeuing, or the time when the outgoing
// interface frees up from the last packet - whatever is later. t2 is then
// the current local time, which could be 200 usec later.
//
// This dequeuing is more expensive, because it needs to serch the whole
// DBF queue: the packet that can be sent first in the interval [t1...t2]
// Is not necessarily the first one found (highest priority), but a later
// pifo packet - because that later packet may be sendable closer to t1
// than the higher priority packet.
// 

int pifo_dequeue_callback( 
    struct dequeue_context *c,
    void *(*callback)(struct dequeue_context *))
{
    struct timespec tsend, cand_tsend;
    struct hnode *curr_hnode = c->qh->hnode1;
    struct hnode *cand_hnode = NULL;
    struct pnode *curr_pnode;
    int    res;
    char   logstring[256];

    c->flags = 0;

    while (curr_hnode) {
        curr_pnode = curr_hnode->pifo;
        while (curr_pnode) {
            // res:
            // -2: Node is expired - purge here.
            // -1: node not ready to be sent in range [t1...t2]
            //  0: node can be sent at t1 - exit condition
            //  1: node can be sent after t1 but before t2.
            //     need to continue search for potentially better candidate
            res = stime_compare_range(&(c->tdqmin), &(c->tdqmax), &tsend,
                                     curr_pnode->tmin_sec, curr_pnode->tmin_usec,
                                     curr_pnode->tmax_sec, curr_pnode->tmax_usec);                

            if (res == -2) { // node expired
                // XXX this can loop a while, causing performance issues
		
		// Fill stats context for examination by callback
                c->pktbuf = curr_pnode->realpkt;

                c->pktstat = res; // discarded for being late
                c->trcv.tv_sec   = curr_pnode->trcv_sec;
                c->trcv.tv_nsec  = curr_pnode->trcv_usec * 1000;

		c->tqmin.tv_sec  = curr_pnode->tmin_sec;
		c->tqmin.tv_nsec = curr_pnode->tmin_usec * 1000;
		c->tqmax.tv_sec  = curr_pnode->tmax_sec;
		c->tqmax.tv_nsec = curr_pnode->tmax_usec * 1000;
                c->flags |= LATEENTRIES;

                curr_hnode->pifo = curr_pnode->next_pnode;
                free(curr_pnode);
                c->qh->packets--;
                curr_pnode = curr_hnode->pifo;
		
                // free(curr_pnode->realpkt) - to be handled by callback
		(*callback)(c);
            }
            if (res == -1) {
                c->flags |= EARLYENTRIES;
                break; // nothing more to do in this pifo, go to next hnode
            }
            if (res == 0) { // we're done!
                c->pktbuf = curr_pnode->realpkt;
		c->tsend = tsend;
                c->pktstat = res; // send immediately.
                c->trcv.tv_sec   = curr_pnode->trcv_sec;
                c->trcv.tv_nsec  = curr_pnode->trcv_usec * 1000;

		c->tqmin.tv_sec  = curr_pnode->tmin_sec;
		c->tqmin.tv_nsec = curr_pnode->tmin_usec * 1000;
		c->tqmax.tv_sec  = curr_pnode->tmax_sec;
		c->tqmax.tv_nsec = curr_pnode->tmax_usec * 1000;

                curr_hnode->pifo = curr_pnode->next_pnode;
                free(curr_pnode);
                c->qh->packets--;
		
                // We should be deleting this hnode as well if its empty,
                // but given how it indicates a particular lqdelay budget, the
                // likelyhood is probably high that we would need to recreate
                // it quickly again.
		(*callback)(c);
                return 1;
            }
            if (res == 1) { 
                if(!cand_hnode ||
                   stime_diff(cand_hnode->pifo->tmin_sec, cand_hnode->pifo->tmin_usec,
                              curr_pnode->tmin_sec, curr_pnode->tmin_usec) < 0) {
		    cand_hnode = curr_hnode;
		    cand_tsend = tsend;
		}
                break; // continue with next hnode to find potentially earlier candidate
            }
        }
        curr_hnode = curr_hnode->next_hnode;
    }
    if(cand_hnode) {
	curr_pnode = cand_hnode->pifo;

        c->pktbuf = curr_pnode->realpkt;
	c->tsend = cand_tsend;
        c->pktstat = 1; // send after tqdmin

        c->trcv.tv_sec   = curr_pnode->trcv_sec;
        c->trcv.tv_nsec  = curr_pnode->trcv_usec * 1000;
	c->tqmin.tv_sec  = curr_pnode->tmin_sec;
	c->tqmin.tv_nsec = curr_pnode->tmin_usec * 1000;
	c->tqmax.tv_sec  = curr_pnode->tmax_sec;
	c->tqmax.tv_nsec = curr_pnode->tmax_usec * 1000;

        cand_hnode->pifo = curr_pnode->next_pnode;
        free(curr_pnode);
        c->qh->packets--;

	(*callback)(c);
        return 1;
    } 
    return 0;
}

void pifo_init_qh(struct pifo_qhead *qh)
{
    qh->hnode1 = NULL;
    qh->packets = 0;
}

/*void walk(struct hnode *walk_hnode)
{
    struct pnode *walk_pnode;
    while (walk_hnode) {
        printf("hnode range start: %hu range end: %hu\n",
               walk_hnode->range_start, walk_hnode->range_end);
        walk_pnode = walk_hnode->pifo;
        while (walk_pnode) {
            printf("pnode min: %hu max: %hu\n", walk_pnode->dmin,
                   walk_pnode->dmax);
            walk_pnode = walk_pnode->next_pnode;
        }
        walk_hnode = walk_hnode->next_hnode;
    }
}*/
