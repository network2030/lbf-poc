/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#define EARLYENTRIES 1
#define LATEENTRIES 2

#define LQB_BESTEFFORT 64000
#define DMAX_BESTEFFORT 10000

struct hnode {
    uint16_t range_start;
    uint16_t range_end;
    struct pnode *pifo;
    struct hnode *next_hnode;
};

struct pnode {
    unsigned long tmin_sec;
    unsigned long tmin_usec;
    unsigned long tmax_sec;
    unsigned long tmax_usec;
    unsigned long trcv_sec;
    unsigned long trcv_usec;
    struct pnode *next_pnode;
    char *realpkt;
};

struct dequeue_context {
    void *oargv;
    int sockfd;
    long mytid;
    char *pktbuf;
    int pktstat;
    struct pifo_qhead *qh;
    // 
    int flags;
    // input for pifo_dequeue: [tdqmin...tdqmax] deque time range
    struct timespec t0;               // timestamp for start of program run
    struct timespec last_tdqmin;
    // current range for dequeuing:
    // tdqmin - end of serialization of previous packet
    // tdqmax - virtual time at which deque operates. may be behind
    //          realtime by a static/dynamic offset
    struct timespec tdqmin, tdqmax;
    struct timespec trcv, tsend, tqmin, tqmax;
    struct timespec tsstart;
};

struct pifo_qhead {
    //pthread_mutex_t qlock;
    pthread_spinlock_t qlock;
    struct hnode *hnode1;
    struct dequeue_context *c;
    int packets; // number of packets in pifo.
};


int pifo_enqueue(struct pifo_qhead *, char *, unsigned short, unsigned long, 
                 unsigned long, unsigned long, unsigned long,
                 unsigned long, unsigned long);
// char *pifo_dequeue(struct pifo_qhead *, struct timespec *currtime,
//                    unsigned long *rcv_sec, unsigned long *rcv_usec,
// 		   int *);
void pifo_init_qh(struct pifo_qhead *);
char *pifo_dequeue_range(struct pifo_qhead *qh,
                         struct timespec *t1,
			 struct timespec *t2,
                         struct timespec *trcv,
                         struct timespec *tsend,
                         struct timespec *tqmin,
                         struct timespec *tqmax,
                         int *flags);
int pifo_dequeue_callback(struct dequeue_context *c,
	                  void *(*callback)(struct dequeue_context *));

