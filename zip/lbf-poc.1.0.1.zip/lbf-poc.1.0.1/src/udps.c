/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include "stime.h"
#include "evlog.h"
#include "pkt.h"

void usage()
{
    fprintf(stderr, "usage: udps -p <port> -i <sender-string> -d <dest-addr> -e <E_DELAY> -m <MIN DELAY> -M <MAX DELAY> -b <bps> [-s <pkt-size>] [-t <burst-int-usec>:<burst-usec>:<burst-bps>] -r <runtime-sec> -S <start-time>\n");
}

uint64_t now()
{
    struct timespec ts;

    if (clock_gettime(CLOCK_MONOTONIC, &ts)) {
        fprintf(stderr, "problem reading clock\n");
        exit (1);
    }
    return ts.tv_sec * 1000000000 + ts.tv_nsec;
}

#define nsec2ts(t) ((t)/1000000000) , ((t)%1000000000) 
#define s2n(s) ((s)*1000000000)

int main(int argc, char **argv)
{
    int c;
    //char buffer[SRV_MSGLEN];
    char pktid[PKTIDLEN];
    char message[CLNT_MSGLEN];
    int sockfd, n;
    struct sockaddr_in servaddr;
    int pflg, iflg, eflg, mflg, Mflg, dflg, rflg, bflg, sflg, tflg;
    uint16_t e_delay_usec, min_delay_usec, max_delay_usec;
    int uinp;
    char *msgp, *sndtimep;
    struct in_addr dest_addr;
    char addrstr[INET_ADDRSTRLEN];
    unsigned short port;

    uint64_t bps, bbps, burst_int_nsec, burst_dur_nsec;
    uint64_t runtime_sec, pktgap_1p_nsec, pktgap_nsec, burst_pktgap_nsec;
    uint64_t tstart_nsec, tnow_nsec, tsnd_nsec, tburst_start_nsec;
    uint64_t starttime_nsec = 0;
    uint64_t t2, t3;
    struct timespec sndtime_ts;

    int pktnum = 0;
    char pktnumstr[PKTNUMLEN];
    char logstring[LOGLEN];
    uint16_t pktsize = htons(300);
    int ierr;
    char *token, *saveptr1;
    unsigned long pkts = 0;

    bzero(pktid, PKTIDLEN);

    pflg = iflg = dflg = eflg = mflg = Mflg = rflg = bflg = sflg = tflg = 0;
    while ((c = getopt(argc, argv, "p:i:d:e:m:M:r:b:s:t:S:")) != -1)
    switch (c) {

      // nexthop port
      case 'p':
	uinp = atoi(optarg);
	if ((uinp < 0) || (uinp > USHRT_MAX)) {
            fprintf(stderr, "Bad port\n");
	    exit(1);
	}
	port = (unsigned short) uinp;
	pflg++;
        break;

      // send rate
      case 'b':
        uinp = atoi(optarg);
        if ((uinp < 0) || (uinp > 1000000000)) {
            fprintf(stderr, "Bad bps\n");
            exit(1);
        }
        bps = uinp;
        bflg++;
        break;

      // pkt size
      case 's':
        uinp = atoi(optarg);
        if ((uinp < 0) || (uinp > 1400)) {
            fprintf(stderr, "Bad pkt-size\n");
            exit(1);
        }
        pktsize = htons((unsigned short) uinp);
        sflg++;
        break;

      // burst parameters
      case 't':
        ierr = 0;
        token = strtok_r(optarg, ":", &saveptr1);
        if (token == NULL) {
            ierr++;
            break;
        }
        uinp = atoi(token);
        if ((uinp < 0) || (uinp > 100000000)) {
            fprintf(stderr, "bad burst interval [usec]\n");
            ierr++;
            break;
        }
        burst_int_nsec = uinp * 1000;

        token = strtok_r(NULL, ":", &saveptr1);
        if (token == NULL) {
            ierr++;
            break;
        }
        uinp = atoi(token);
        if ((uinp < 0) || (uinp > 100000000)) {
            fprintf(stderr, "bad burst duration [usec]\n");
            ierr++;
            break;
        }
        burst_dur_nsec = uinp * 1000;

        token = strtok_r(NULL, ":", &saveptr1);
        if (token == NULL) {
            ierr++;
            break;
        }
        uinp = atoi(token);
        if ((uinp < 0) || (uinp > 1000000000)) {
            fprintf(stderr, "Bad burst bps\n");
            ierr++;
        }
        bbps = uinp;
        if (!ierr)
            tflg++;
        break;

      // input string (pktid)
      case 'i':
        strncpy(pktid, optarg, CLNTIDLEN - 1);
	iflg++;
        break;

      // destination address
      case 'd':
	if (inet_pton(AF_INET, optarg, &dest_addr) != 1) {
            fprintf(stderr, "Bad dest addr\n");
	    exit(1);
	}
	dflg++;
	break;

      // edelay
      case 'e':
	uinp = atoi(optarg);
	if ((uinp < 0) || (uinp > USHRT_MAX)) {
            fprintf(stderr, "Bad e_delay [usec]\n");
	    exit(1);
	}
	e_delay_usec = htons((uint16_t) uinp);
	eflg++;
        break;

      // min_delay
      case 'm':
	uinp = atoi(optarg);
	if ((uinp < 0) || (uinp > USHRT_MAX)) {
            fprintf(stderr, "Bad min_delay [usec]\n");
	    exit(1);
	}
	min_delay_usec = htons((uint16_t) uinp);
	mflg++;
        break;

      // max_delay
      case 'M':
	uinp = atoi(optarg);
	if ((uinp < 0) || (uinp > USHRT_MAX)) {
            fprintf(stderr, "Bad max_delay [usec]\n");
	    exit(1);
	}
	max_delay_usec = htons((uint32_t) uinp);
	Mflg++;
        break;

      /* Runtime */
      case 'r':
        uinp = atoi(optarg);
        if ((uinp < 0) || (uinp > 100)) {
            fprintf(stderr, "bad runtime [sec]\n");
            exit(1);
        }
        runtime_sec = uinp;
        rflg++;
        break;

      /* Starttime */
      case 'S': {
	uint64_t tnow = now();
        starttime_nsec = atoi(optarg) * 1000000000L;
	if(starttime_nsec < tnow - 1000000000L) {
	    fprintf(stderr, "Invalid starttime %ld, ignored (now: %ld)\n", starttime_nsec, tnow);
	    starttime_nsec = 0;
	}
        break;
      }

      default:
	usage();
	exit(1);
    }

    if (!pflg || !iflg || !dflg || !eflg || !mflg || !Mflg || !rflg || !bflg) {
        usage();
	exit(1);
    }

    if (!inet_ntop(AF_INET, &dest_addr, addrstr, INET_ADDRSTRLEN)) {
        fprintf(stderr, "Problem converting dest addr\n");
        exit(1);
    }

    if (tflg) {
        if (s2n(runtime_sec) < burst_int_nsec) {
            fprintf(stderr, "burst interval too high\n");
            exit(1);
        }
        if (burst_int_nsec < burst_dur_nsec) {
            fprintf(stderr, "burst interval too small\n");
            exit(1);
        }
    }
    
    printf("Sender details:\n");
    printf("  Emulation:    dest addr %s port %hu pkt id %s pktsize %hu\n",
	                    addrstr, port, pktid, ntohs(pktsize));
    printf("  DBF params:   e_delay %hu [usec] min_delay %hu [usec] max_delay %hu [usec]\n",
		            ntohs(e_delay_usec), ntohs(min_delay_usec), ntohs(max_delay_usec));
    printf("  Flow params:  rate %lu [bps] runtime %lu [sec]\n",
		            bps, runtime_sec);
    if(tflg) {
        printf("  Burst params: burst rate %lu [bps] interval %lu [nsec] burst duration %lu [nsec]\n",
                                bbps, burst_int_nsec, burst_dur_nsec);
    }
    printf("\n");

    // prepare packet template
    msgp = message;
    msgp += PKTIDLEN;
    memcpy(msgp, (void *) &dest_addr, sizeof(dest_addr));
    msgp += sizeof(dest_addr);
    memcpy(msgp, (void *) &e_delay_usec, sizeof (uint16_t));
    msgp += sizeof (uint16_t);
    memcpy(msgp, (void *) &min_delay_usec, sizeof (uint16_t));
    msgp += sizeof (uint16_t);
    memcpy(msgp, (void *) &max_delay_usec, sizeof (uint16_t));
    msgp += sizeof (uint16_t);
    memcpy(msgp, (void *) &pktsize, sizeof (uint16_t));
    msgp += sizeof (uint16_t);
    sndtimep = msgp;
 
    // clear servaddr
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(port);
    servaddr.sin_family = AF_INET;
 
    // create datagram socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
 
    // connect to server
    if (connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
        printf("\n Error : Connect Failed \n");
        exit(1);
    }

    pktgap_1p_nsec = ntohs(pktsize) * 80;
    pktgap_nsec = ntohs(pktsize) * 8000000000 / bps;
    printf("inter packet gap is %lu [nsec]\n", pktgap_nsec);

    if (tflg) {
        burst_pktgap_nsec = ntohs(pktsize) * 8000000000 / bbps;
        printf("inter packet gap during burst is %lu [nsec]\n", burst_pktgap_nsec);
    }

    if (!tflg)
        burst_int_nsec = s2n(runtime_sec);

    // Sync to starttime, so all senders can synchronuously (or later).
    if(starttime_nsec) {
        starttime_nsec += 2000000000L;
        while(now() < starttime_nsec) {} 
    } else {
	starttime_nsec = now();
    }

    tsnd_nsec = tburst_start_nsec = tstart_nsec = starttime_nsec;

    while (1) {
        tnow_nsec = now();

	if (tnow_nsec - tstart_nsec > s2n(runtime_sec)) {
            printf("sent %lu packets, time up, exiting\n", pkts);
            close(sockfd);
            exit (0);
        }
	if (tnow_nsec < tsnd_nsec) {
            continue;
        }
	
	// randomize the gap by +-1 percent
	// double gap; // gap = curr_pktgap * 1000;
	// stime_add_ts(&sndtime_ts, FUTURE, &sndtime_ts);
	
	strcpy(message, pktid);

	snprintf(pktnumstr, PKTNUMLEN, "%d", pktnum++);
	strcat(message, pktnumstr);

	sndtime_ts.tv_sec  = tsnd_nsec / 1000000000;
	sndtime_ts.tv_nsec = tsnd_nsec % 1000000000;
        memcpy(sndtimep, (void *) &sndtime_ts, sizeof(sndtime_ts));

        sendto(sockfd, message, CLNT_MSGLEN, MSG_DONTWAIT,
               (struct sockaddr*) NULL, 0);
	if (snprintf(logstring, LOGLEN, "%11s pkt sent\n", message) > LOGLEN) {
            fprintf(stderr, "LOG error, exiting\n");
            exit(1);
        }
	evlog(stdout, logstring);
	
	pkts++;

	if(tflg) {
	    // tburst_start_nsec........ t2 ............ t3
	    //                           |<....inburst...>|
	    t3 = tburst_start_nsec + burst_int_nsec;
    
	    t2 = t3 - burst_dur_nsec;
    
   #define max(a,b) (((a) > (b)) ? (a) : (b))
    
	    if (tsnd_nsec < t2) {
	        if(tsnd_nsec + pktgap_nsec >= t2) {
                    tsnd_nsec = max(t2,tsnd_nsec + pktgap_1p_nsec);
                    printf("%9lu %9lu Enter burst mode\n", nsec2ts(tsnd_nsec));
	        } else {
	            tsnd_nsec += pktgap_nsec;
	        }
	    } else
	    if (tsnd_nsec + burst_pktgap_nsec >= t3) {
	        tburst_start_nsec = t3;
	        tsnd_nsec = max(t3, tsnd_nsec + pktgap_1p_nsec);
                printf("%9lu %9lu Exit burst mode\n", nsec2ts(tsnd_nsec));
	    } else  {
	        tsnd_nsec += burst_pktgap_nsec;
	    }
	} else {
	    tsnd_nsec += pktgap_nsec;
	}
    }
    // close the descriptor
    close(sockfd);
}
