/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

struct qent {
    char *realpkt;
    struct qent *nextpkt;
    // when to dequeue, in case it is a timeed fifo
    unsigned long rmin_sec;  
    unsigned long rmin_usec;
};

// deposited by iif threads, read by oif threads
struct fifo_qhead {
    pthread_mutex_t qlock;
    struct qent *pktf;
    struct qent *pktl;
};

void fifo_enqueue(struct fifo_qhead *, char *, unsigned long, unsigned long);
char *fifo_dequeue(struct fifo_qhead *, unsigned long, unsigned long, unsigned long *);
void fifo_init_qh(struct fifo_qhead *);
