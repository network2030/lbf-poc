/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#include <stdio.h>
#include <time.h>

// XXX go back to using timespec instead of sec/usec everywhere

int stime_isless(unsigned long tmin_sec, unsigned long tmin_usec,
                 unsigned long tmin_sec_c, unsigned long tmin_usec_c)
{
    if (tmin_sec < tmin_sec_c)
        return 1;
    else if ((tmin_sec == tmin_sec_c) && (tmin_usec < tmin_usec_c))
        return 1;
    else
        return 0;
}

// Is first ts less than second ?
int stime_isless_ts(struct timespec *ts1, struct timespec *ts2)
{
    if (ts1->tv_sec < ts2->tv_sec)
        return 1;
    else if ((ts1->tv_sec == ts2->tv_sec) && (ts1->tv_nsec < ts2->tv_nsec))
        return 1;
    else
        return 0;
}


// time to check is in usec XXX overflow possible for large runtime
int stime_iselapsed(struct timespec *ts1, struct timespec *ts2,
                    unsigned long checktime)
{
    unsigned long elapsed_usec;
    elapsed_usec = (ts2->tv_sec - ts1->tv_sec) * 1000000 +
        (ts2->tv_nsec - ts1->tv_nsec)/1000;
    if (elapsed_usec > checktime)
        return 1;
    else
        return 0;
}

// time to check is in usec XXX overflow possible for large runtime
int stime_iselapsed_nsec(struct timespec *ts1, struct timespec *ts2,
                    unsigned long checktime)
{
    unsigned long elapsed_usec;
    elapsed_usec = (ts2->tv_sec - ts1->tv_sec) * 1000000000 +
        (ts2->tv_nsec - ts1->tv_nsec);
    if (elapsed_usec > checktime)
        return 1;
    else
        return 0;
}

// add nsec to timespec
void stime_add_ts(struct timespec *ts, unsigned long nsec,
                  struct timespec *ts_ret)
{
    unsigned long tmp_sec, tmp_nsec;

    tmp_sec = ts->tv_sec;
    tmp_nsec = ts->tv_nsec + nsec;
    if (tmp_nsec > 1000000000) {
        tmp_sec += 1;
        tmp_nsec -= 1000000000;
    }
    ts_ret->tv_sec = tmp_sec;
    ts_ret->tv_nsec = tmp_nsec;
}

// incr and result in usec, but original in nsec
void stime_add(unsigned long sec1, unsigned long nsec1, unsigned short incr,
               unsigned long *res_sec, unsigned long *res_usec)
{
    unsigned long tmp_sec, tmp_nsec;

    tmp_nsec = nsec1 + incr * 1000;
    if (tmp_nsec > 1000000000) {
        tmp_sec = sec1 + 1;
        tmp_nsec = tmp_nsec - 1000000000;
    } else {
        tmp_sec = sec1;
    }
    *res_sec = tmp_sec;
    *res_usec = tmp_nsec/1000;
}

// return in usec
// unsigned long stime_difftv(struct timespec *ts1, struct timespec *ts2)
long stime_difftv(struct timespec *ts1, struct timespec *ts2)
{
    return ((ts2->tv_sec - ts1->tv_sec) * 1000000000L +
             (ts2->tv_nsec - ts1->tv_nsec)) / 1000L;
}

// sec/usec only
long stime_diff(unsigned long sec1, unsigned long usec1,
                unsigned long sec2, unsigned long usec2)
{
    return ((sec2 - sec1) * 1000000 + usec2 - usec1);
}

// return -ve if too early, +ve if too late, 0 otherwise
int stime_compare(struct timespec *ts, unsigned long tmin_sec,
                  unsigned long tmin_usec, unsigned long tmax_sec,
                  unsigned long tmax_usec)
{
    long min_diff, max_diff;

    min_diff = (ts->tv_sec - tmin_sec) * 1000000 +
               (ts->tv_nsec/1000 - tmin_usec);
    //printf("min diff %ld\n", min_diff);
    if (min_diff > 0) {
        max_diff =
            (tmax_sec - ts->tv_sec) * 1000000 + (tmax_usec - ts->tv_nsec/1000);
        //printf("max diff %ld\n", max_diff);
	if (max_diff >= 0)
            return 0;
        else
            return 1;
    } else
        return -1;
}

#if 0

int stime_gt(struct timespec *ts1, struct timespec *ts2)
{
    return ((ts1->tv_sec - ts2->tv_sec) * 1000000 +
            ((ts1->tv_nsec/1000) - (ts2->tv_nsec/1000))) > 0;
}

int stime_lt(struct timespec *ts1, struct timespec *ts2)
{
    return ((ts1->tv_sec - ts2->tv_sec) * 1000000 +
            ((ts1->tv_nsec/1000) - (ts2->tv_nsec/1000))) < 0;
}
#endif


int stime_lt(struct timespec *ts1, struct timespec *ts2)
{
    return ((ts1->tv_sec - ts2->tv_sec) * 1000000000 +
            ((ts1->tv_nsec) - (ts2->tv_nsec))) < 0;
}

// return -ve if too early, +ve if too late, 0 otherwise
int stime_compare_range(struct timespec *ts1, struct timespec *ts2,
		   struct timespec *tsend,
	           unsigned long tmin_sec, unsigned long tmin_usec,
		   unsigned long tmax_sec, unsigned long tmax_usec)
{
    struct timespec tmin, tmax;
    tmin.tv_sec = tmin_sec; tmin.tv_nsec = tmin_usec * 1000;
    tmax.tv_sec = tmax_sec; tmax.tv_nsec = tmax_usec * 1000;

    if (stime_lt(&tmax, ts1)) return -2; // expired
    if (stime_lt(ts2, &tmin)) return -1; // too early
    if (stime_lt(ts1, &tmin)) {
        *tsend = tmin;
        return 1; // packet can only be sent after ts1
    }
    *tsend = *ts1; 
    return 0; // packet can be sent earlier or at ts1
}
