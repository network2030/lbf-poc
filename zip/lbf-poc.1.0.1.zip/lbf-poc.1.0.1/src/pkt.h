/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#define PKTIDLEN 32
#define CLNTIDLEN 16
#define PKTNUMLEN 16
#define CLNT_MSGLEN 64
/*
 * Sequence of data/headers in packet:
 * This is ugly coded right now, should be a struct.
 *  Stub diagnostics header:
 *     packet name (PKTIDLEN )            32
 *  Stub IP header:
 *     dest_addr (in_addr)                 4
 *     Stub new service header: ("BPP")
 *     e_delay   (16 bit unsigned)         2
 *     min_delay (16 bit unsigned)         2
 *     max_delay (16 bit unsigned)         2
 *  Emulation stub
 *     pktsize (16 bit unsigned)           2
 *     - calc packet serialization time
 *     sndtime  - clock timestamp          8
 *
 *     Used so far: 52
 */

#define IFBITRATE 100000000
