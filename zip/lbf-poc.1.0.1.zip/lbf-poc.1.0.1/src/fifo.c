/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "fifo.h"
#include "stime.h"

void fifo_enqueue(struct fifo_qhead *qh, char *pktbuf, unsigned long rmin_sec,
                  unsigned long rmin_usec)
{
    struct qent *qe;

    qe = calloc(1, sizeof (struct qent));
    if (qe != NULL) {
        qe->realpkt = pktbuf;
	qe->rmin_sec = rmin_sec;
	qe->rmin_usec = rmin_usec;
        if (qh->pktf == NULL) {
            qh->pktf = qh->pktl = qe;
        } else {
            qh->pktl->nextpkt = qe;
            qh->pktl = qe;
        }
    }
}

#define TSdiff(t1,t2) ( (long) ((t2.tv_sec - t1.tv_sec) * 1000000000 + t2.tv_nsec - t1.tv_nsec) )

char *fifo_dequeue(struct fifo_qhead *qh, unsigned long tnow_sec,
                   unsigned long tnow_nsec, unsigned long *late)
{
    struct qent *qe;
    char *realpkt;

    if (qh->pktf == NULL) {
        //printf("queue empty\n");
        return NULL;
    }
    qe = qh->pktf;
    if (tnow_sec &&
        (stime_isless(tnow_sec, tnow_nsec/1000, qe->rmin_sec, qe->rmin_usec))) {
        //printf("queue not empty but nothing ready\n");
        return NULL;
    }
    if (qh->pktf == qh->pktl)
        qh->pktf = qh->pktl = NULL;
    else
        qh->pktf = qh->pktf->nextpkt;
    realpkt = qe->realpkt;
    free(qe);
    if(late) {
	*late = (unsigned long) ((tnow_sec - qe->rmin_sec) * 1000000000 + tnow_nsec - qe->rmin_usec * 1000);
    }
    return realpkt;
}

void fifo_init_qh(struct fifo_qhead *qh)
{
    qh->pktf = NULL;
    qh->pktl = NULL;
}
