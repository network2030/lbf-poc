/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

int stime_isless(unsigned long, unsigned long, unsigned long, unsigned long);
int stime_iselapsed(struct timespec *, struct timespec *, unsigned long);
void stime_add(unsigned long, unsigned long, unsigned short, unsigned long *,
               unsigned long *);
unsigned long stime_difftv(struct timespec *, struct timespec *);
unsigned long stime_diff(unsigned long, unsigned long, unsigned long,
                         unsigned long);
int stime_compare(struct timespec *, unsigned long, unsigned long,
                  unsigned long, unsigned long);
void stime_add_ts(struct timespec *, unsigned long, struct timespec *);
int stime_isless_ts(struct timespec *, struct timespec *);
int stime_lt(struct timespec *ts1, struct timespec *ts2);
int stime_compare_range(struct timespec *ts1, struct timespec *ts2,
	                struct timespec *tsend,
	                unsigned long tmin_sec, unsigned long tmin_usec,
	                unsigned long tmax_sec, unsigned long tmax_usec);
