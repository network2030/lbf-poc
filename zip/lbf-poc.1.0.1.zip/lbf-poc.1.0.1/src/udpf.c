/******************************************************************************
 * Copyright 2019,2020 Futurewei Technologies, Inc.  All rights reserved.     *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License");            *
 * you may not use this file except in compliance with the License.           *
 * You may obtain a copy of the License at                                    *
 *                                                                            *
 *     http://www.apache.org/licenses/LICENSE-2.0                             *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 ******************************************************************************/

#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <limits.h>
#include <time.h>
#include <errno.h>
#include "fifo.h"
#include "pifo.h"
#include "stime.h"
#include "evlog.h"
#include "pkt.h"

#define PKTIDLEN 32
#define CLNT_MSGLEN 64
#define EXPIDLEN 16
#define FWDIDLEN 16
#define MAX_IIF 8
#define MAX_OIF 8
#define MAX_FIB 8

struct fib {
    struct in_addr dest_addr;
    unsigned short oif_index;
    unsigned short nh_port;
    unsigned short todelay;
    unsigned short tohops;
};

struct iif_arg {
    unsigned short port;
    uint16_t hdelay;
    unsigned long runtime;
    unsigned short num_fib;
    struct fib *fibptr;
    struct pifo_qhead *qhptr;
    FILE *logs;
    int coreid;
};

struct oif_arg {
    unsigned short index;
    unsigned short nh_port;
    unsigned long runtime;
    struct pifo_qhead *qhptr;
    FILE *logs;
    int odelay;
    int nosend;
    int coreid;
};

static int (*pifo_dequeue)(struct dequeue_context *, void *(*)(struct dequeue_context *)) = pifo_dequeue_callback;

void usage()
{
    fprintf(stderr, "usage: udpf -i <port>:<hdelay>,... -o <index>:<nh-port>:<odelay>[:nosend],... -f <dest-addr>:<oif-index>:<todelay>:<tohops>,... [-c <core-id-start>] -r <runtime> -x <exp-id> -w <fwd-id> [-D]\n");
}

int good_short(int uinp)
{
    if ((uinp < 0) || (uinp > USHRT_MAX))
        return 0;
    else
        return 1;
}

static int attach_core(unsigned long coreid, unsigned long mytid,
                       char *caller_info)
{
    cpu_set_t cpuset;
    int j;

    CPU_ZERO(&cpuset);
    CPU_SET(coreid, &cpuset);
    if (pthread_setaffinity_np(mytid, sizeof(cpu_set_t), &cpuset) != 0) {
        fprintf(stderr, "%lu: setaffinity failed\n", mytid);
        return 1;
    }
    if (pthread_getaffinity_np(mytid, sizeof(cpu_set_t), &cpuset) != 0) {
        fprintf(stderr, "%lu: getaffinity failed\n", mytid);
        return 1;
    }
    for (j = 0; j < CPU_SETSIZE; j++) {
        if (((j == coreid) && !CPU_ISSET(j, &cpuset)) ||
            ((j != coreid) && CPU_ISSET(j, &cpuset))) {
            fprintf(stderr, "%lu: bad affinity detected\n", mytid);
            return 1;
        }
    }
    printf("attached %s %lu to core %lu\n", caller_info, mytid, coreid);
    return 0;
}

#define TS(clock,mytid) \
    if (clock_gettime(CLOCK_MONOTONIC, &clock)) { \
        fprintf(stderr, "%lu: problem reading clock\n", mytid); \
        return NULL; \
    }

#define TSdelay(clock,delay,mytid) \
    if (clock_gettime(CLOCK_MONOTONIC, &clock)) { \
        fprintf(stderr, "%lu: problem reading clock\n", mytid); \
        return NULL; \
    } else { \
        clock.tv_nsec -= delay; \
        if(clock.tv_nsec < 0) { \
            clock.tv_nsec += 1000000000L; \
            clock.tv_sec -= 1; \
        } \
    } \


#define TSdiff(t1,t2) ( (long) ((t2.tv_sec - t1.tv_sec) * 1000000000 + t2.tv_nsec - t1.tv_nsec) )
#define TSzero(t) t.tv_sec = 0; t.tv_nsec = 0;

void *iif_fn(void *iargv)
{
    char buffer[CLNT_MSGLEN];
    int listenfd, len;
    struct sockaddr_in servaddr, cliaddr;
    uint16_t e_delay, e_delay_new, min_delay, max_delay;
    char pktid[PKTIDLEN];
    uint16_t nets;
    char *bufp;
    struct in_addr dest_addr;
    char addrstr[INET_ADDRSTRLEN];
    struct iif_arg *iarg = (struct iif_arg *) iargv;
    int i, fib_fail, badpkt;
    unsigned short fibop;
    pthread_t mytid = pthread_self();
    char *pktbuf;
    unsigned short qmin, qmax, lqmin, lqmax, lqbudget, pktsize;
    unsigned long tmin_sec, tmin_usec, tmax_sec, tmax_usec;
    // unsigned long rmin_sec, rmin_usec;
    struct fifo_qhead rcv_qhead;
    char logstring[LOGLEN];
    unsigned short fib_tohops, fib_todelay;
    char pktid_str[PKTIDLEN];
    int n, r;

    struct timespec tstart, tnow, tnew, trcv, sndtime;

    struct pifo_qhead *p;
    struct timespec tmin;
    struct timespec t0, tdqmin, tdqmax;
    
    // counters for delta-t timestamp printing
    struct timespec tprint_last;
    unsigned long dt_print;

    // counters for [recv->fifo-enqueue]
    unsigned long n_recvpoll, t_recvpoll, t_recv;

    // counters for [fifo-dequeue->dbf-enque operation]
    // unsigned long late;
    unsigned long n_spin, t_spin;

    long delay;
    int linuxlate;

    if (iarg->coreid >= 0)
        if (attach_core(iarg->coreid, mytid, "IIF thread"))
            return NULL;

    fifo_init_qh(&rcv_qhead);

    bzero(&servaddr, sizeof(servaddr));
  
    // Create a UDP Socket
    listenfd = socket(AF_INET, SOCK_DGRAM, 0);
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(iarg->port);
    servaddr.sin_family = AF_INET;
 
    // bind server address to socket descriptor
    bind(listenfd, (struct sockaddr*) &servaddr, sizeof(servaddr));

    len = sizeof(cliaddr);

    printf("IIF thread %lu listening on port %hu\n", mytid, iarg->port);
    printf("fibs available:\n");
    for (i = 0; i < iarg->num_fib; i++) {
        if (!inet_ntop(AF_INET, (void *) &iarg->fibptr[i].dest_addr, addrstr,
                       INET_ADDRSTRLEN)) {
            fprintf(stderr, "iif thread read bad dest addr\n");
        }
        printf("dest addr %s nh-port %hu\n", addrstr, iarg->fibptr[i].nh_port);
    }

    // We log the times taken by each step of a mayor operation.
    //
    // A mayor operation is receiving a packet or sending a packet.
    // A mayor operation may run many times through the while(1)
    // loop because we actively poll the receive socket and the
    // send-side spin-socket so that we minimize the latency in
    // performing the operations.
    //
    // Counters of interest:
    //
    // n_recvpoll   - number of times we polled recv
    // t_recvpoll   - amount of time spent polling recv [nsec]
    // t_recv       - time spent in recv syscall [nsec]


    TS(tnow,mytid);          // update after every system call
    tstart = tnow;
    tprint_last = tnow;

    // Initialize counters to diagnose [recv->fifo-enqueue] operations

    n_recvpoll = 0;
    t_recvpoll = 0;
    t_recv = 0;

    while (1) {
        
        // Check if we should quit
        
        if (stime_iselapsed(&tstart, &tnow, iarg->runtime * 1000000)) {
            printf("%lu exiting, time up\n", mytid);
            return NULL;
        }
        
        // poll for packet, exit upon error condition
        
        n = recvfrom(listenfd, buffer, CLNT_MSGLEN, MSG_DONTWAIT,
                         (struct sockaddr*) &cliaddr, &len);
        if ((n > 0) && (n != CLNT_MSGLEN)) {
            fprintf(stderr, "%lu: Read unexpected number of bytes %d\n",
                    mytid, n);
            return(NULL);
        } else if ((n == -1) &&
                   !((errno == EAGAIN) || (errno == EWOULDBLOCK))) {
            fprintf(stderr, "%lu: unexpected error on read\n", mytid);
            return(NULL);
        }

        // Update receive/polling counters
        {
           unsigned long dt;

           TS(tnew,mytid);
           dt = TSdiff(tnow, tnew);
           tnow = tnew;

           if (n == CLNT_MSGLEN) {
               // actually received a packet
               t_recv = dt;
           } else {
               // just polled, no packet received
               n_recvpoll++;
               t_recvpoll += dt;
           }
        }

        // Receive and enqueue packet
        
        if (n == CLNT_MSGLEN) {
            // copy pkt
            pktbuf = malloc(CLNT_MSGLEN);
            if (pktbuf == NULL) {
                fprintf(stderr, "%lu memory error, exiting\n", mytid);
                return NULL;
            }
            memcpy(pktbuf, buffer, CLNT_MSGLEN);
            
            badpkt = 0;

            // Sequence of data/headers in packet:
            // This is ugly coded right now, should be a struct.
            //   Stub diagnostics header:
            //     packet name (PKTIDLEN )
            //   Stub IP header:
            //     dest_addr (in_addr)
            //   Stub new service header: ("BPP")
            //     e_delay   (16 bit unsigned)
            //     min_delay (16 bit unsigned)
            //     max_delay (16 bit unsigned)
            //   Stub more
            //     pktsize (16 bit unsigned) - to calculate packet serialization time
            //     sndtime - sending time of packet
            
            strcpy(pktid_str, pktbuf);
            bufp = pktbuf + PKTIDLEN;

            memcpy((void *) &dest_addr, bufp, sizeof(dest_addr));
            bufp += sizeof (dest_addr);

            memcpy(&nets, bufp, sizeof (uint16_t));
            e_delay = ntohs(nets);

            bufp += sizeof (uint16_t);
            memcpy(&nets, bufp, sizeof (uint16_t));
            min_delay = ntohs(nets);

            bufp += sizeof (uint16_t);
            memcpy(&nets, bufp, sizeof (uint16_t));
            max_delay = ntohs(nets);

            bufp += sizeof (uint16_t);
            memcpy(&nets, bufp, sizeof (uint16_t));
            pktsize = ntohs(nets);

            bufp += sizeof (uint16_t);
            memcpy(&sndtime, bufp, sizeof(sndtime));

            // Add the delay of the fifo emulated link (hdelay)
            // // plus the actual scheduling delay (late).
            
            // e_delay update
            e_delay_new = e_delay + iarg->hdelay;
            
            nets = htons(e_delay_new);
            bufp = pktbuf + PKTIDLEN + sizeof (dest_addr);
            memcpy(bufp, &nets, sizeof(uint16_t));

            // delay is the delay between the time the packet should have been delayed
            // if e_delay in the packet was correct and reality. We already subtract
            // the time for the recv system call from this delay
            
            delay = TSdiff(sndtime, tnow) - e_delay * 1000;

            n_recvpoll = 0;
            t_recvpoll = 0;
            t_recv = 0;

            // Lookup FIB
            
            fib_fail = 1;
            for (i = 0; i < iarg->num_fib; i++) {
                if (!memcmp(&iarg->fibptr[i].dest_addr, &dest_addr,
                            sizeof(struct in_addr))) {
                    fib_fail = 0;
                    fibop = iarg->fibptr[i].oif_index;
                    fib_todelay = iarg->fibptr[i].todelay;
                    fib_tohops = iarg->fibptr[i].tohops;
                    
                    break;
                }
            }
            if (fib_fail) {
                fprintf(stderr, "%lu: fib match failed\n", mytid);
                return(NULL);
            }

            // Perform queue and protocol specific tasks
            // DBF and best effort is supported, no specific parameter
            // is used, instead protocol is derived from existing 
            // parameters like min/max delay (might need revisit XXX)

            // early discard
            if (max_delay != 0) { // DBF
                if ((e_delay_new + fib_todelay) > max_delay) {
                    if (snprintf(logstring, LOGLEN,
                         "%s iif early discard edelay %hu todelay %hu "
                         "maxdelay %hu\n", pktid_str, e_delay_new,
                         fib_todelay, max_delay) > LOGLEN) {
                        fprintf(stderr, "%lu LOG error, exiting\n", mytid);
                        return(NULL);
                    }
                    evlog(iarg->logs, logstring);
                    badpkt++;
                }
            }

            // Calculate delay budgets

            if (min_delay < (e_delay_new + fib_todelay))
                qmin = 0;
            else
                qmin = min_delay - (e_delay_new + fib_todelay);

            lqmin = qmin / fib_tohops;

            if (max_delay > 0) { // DBF packet
                qmax = max_delay - (e_delay_new + fib_todelay);

                lqmax = qmax / fib_tohops;
                lqbudget = lqmax - lqmin;
            } else
            if (max_delay == 0) { // best effort packet
                lqmax = DMAX_BESTEFFORT;
                lqbudget = LQB_BESTEFFORT;
            }

            // The received packet is too 'early' because it was not delayed by
            // the hdelay of the receiving interface. If we would try to do that,
            // then we would have a hard time to compensate for scheduling glitches
            // in linux.
            // The dbf pifo algorithm already needs to calculate a min/max local
            // timestamp where dequeuing of the packet is desired. We simply need
            // to add hdelay to that timestamp to dequeue the packet in the
            // right time interval
            
            // tmin_sec, tmin_usec:
            // Calculate absolute time range when we can send the packet

            // # This should give accuracy because it uses the timestamp from the sender process:
            
             stime_add(sndtime.tv_sec, sndtime.tv_nsec, e_delay_new + lqmin, &tmin_sec, &tmin_usec);
             stime_add(sndtime.tv_sec, sndtime.tv_nsec, e_delay_new + lqmax, &tmax_sec, &tmax_usec);

	     tmin.tv_sec = tmin_sec;
	     tmin.tv_nsec = tmin_usec * 1000;
            
            // stime_add(tnow.tv_sec, tnow.tv_nsec, iarg->hdelay + lqmin, &tmin_sec, &tmin_usec);
            // stime_add(tnow.tv_sec, tnow.tv_nsec, iarg->hdelay + lqmax, &tmax_sec, &tmax_usec);

            // trcv: 
            // Calculate time at which oif_fn thinks the packet was received.
            // This is then used to calculate how long the packet stayed in the
            // the DBF queue.

            stime_add_ts(&sndtime, e_delay_new * 1000, &trcv);
            
            // stime_add_ts(&tnow, e_delay_new * 1000, &trcv);

            if (!badpkt) {

                n_spin = 0;

                // get lock to write packet into egress PIFO
                // count how long we are waiting on spinlock for diagnostics
                
                while(r = pthread_spin_trylock(&(iarg->qhptr[fibop].qlock))) {
                        if (r != EBUSY) {
                            fprintf(stderr, "%lu: spinlock problem\n", mytid);
                            return NULL;
                        } else {
                            TS(tnew,mytid);
                            n_spin++;
                        }
                }

		// ================== START CRITICIAL REGION ====================
		
                t_spin = TSdiff(tnow,tnew);
                tnow = tnew;

                p = &(iarg->qhptr[fibop]);

		// dequeue process dequeues from tdqmin...tdqmax
		// as soon as the tmin dequeuing time of the packet
		// is older (less) than tdqmax it means the packet
		// is too late to enqueue - because it would not necessarily
		// be dequeued correctly (or at all).

		tdqmin = p->c->tdqmin; // need local variables for multi thread
		tdqmax = p->c->tdqmax; // safe logging after critical region
		t0 = p->c->t0;
		linuxlate =  stime_lt(&tmin,&tdqmax);
		if(!linuxlate) {
                    pifo_enqueue(p, pktbuf,
                        lqbudget, tmin_sec, tmin_usec, tmax_sec, tmax_usec,
                        trcv.tv_sec, trcv.tv_nsec/1000);
		}

		// ================== END CRITICIAL REGION ======================

                if (pthread_spin_unlock(&(iarg->qhptr[fibop].qlock))) {
                    fprintf(stderr, "%lu: spinlock problem\n", mytid);
                    return NULL;
                }

		if(linuxlate) {
                    if(snprintf(logstring, LOGLEN,
                             "%11s enq ed %4u lslo %4u %4u dqm/m,tmin %11ld %11ld %11ld ahead %6ld %s\n",
                            pktid_str, e_delay_new, lqmin, lqmax, 
		       	    stime_difftv(&t0, &tdqmin), 
		       	    stime_difftv(&t0, &tdqmax),
		       	    stime_difftv(&t0, &tmin),
		       	    stime_difftv(&tdqmax, &tmin),
			    linuxlate ? "LINUXLATE" : ""
			    ) > LOGLEN) {
                        fprintf(stderr, "%lu LOG error, exiting\n", mytid);
                        return(NULL);
                    }
                    evlog(iarg->logs, logstring);
                    free(pktbuf);
		}
            } else {
                // discard
                free(pktbuf);
            }
        }
    }
}

// Called by pifo_dequeue with a packet that has been dequeued.
// expected to dispose of the packet

void *oif_fn_callback(struct dequeue_context *c)
{
    char *bufp;
    uint16_t e_delay, nets, pktsize;
    struct oif_arg *oarg = (struct oif_arg *) c->oargv;
    long gap, qdelay, lqmin, lqmax;
    struct timespec diag_tsnd, diag_tsnd_fin, p_sndtime;
    unsigned long diag_virt_send_time, diag_snd_time;
    char logstring[LOGLEN];
    unsigned long ifbusy_nsec;
    long p_start, p_end;
    long s_min, s_max;
    long tdqmin, tdqmax;
    long t_late;

    // get e_delay and pktsize from packet
    
    bufp = c->pktbuf + PKTIDLEN + sizeof (struct in_addr);
    memcpy(&nets, bufp, sizeof (uint16_t));
    e_delay = ntohs(nets);

    bufp += 3 * sizeof (uint16_t);
    memcpy(&nets, bufp, sizeof (uint16_t));
    pktsize = ntohs(nets);

    bufp += sizeof (uint16_t);
    memcpy(&p_sndtime, bufp, sizeof(p_sndtime));

    // diagnostics: 
    // lqmin, lqmax:   SLO of packet relative to local receive time
    // s_min, s_max:   SLO of packet relative to program start time
    // tdqmin, tdqdmax: current dequeuing min...max relative to program stsart
    
    lqmin  = stime_difftv(&(c->trcv), &(c->tqmin));
    lqmax  = stime_difftv(&(c->trcv), &(c->tqmax));
    s_min  = stime_difftv(&(c->t0), &(c->tqmin));
    s_max  = stime_difftv(&(c->t0), &(c->tqmax));

    tdqmin = stime_difftv(&(c->t0), &(c->tdqmin));
    tdqmax = stime_difftv(&(c->t0), &(c->tdqmax));

    // Calculate time in queue
  
    qdelay = stime_difftv(&(c->trcv), &(c->tsend));
    
    // Log expired packets

    if(c->pktstat == -2) {
        if (snprintf(logstring, LOGLEN, 
             "%11s ldsc ed %4u         lslo %4ld %4ld\n", 
	     c->pktbuf, e_delay, lqmin, lqmax) > LOGLEN) {
            fprintf(stderr, "%lu LOG error, exiting\n", c->mytid);
            return NULL;
        }
        evlog(oarg->logs, logstring);
        free(c->pktbuf);
    }

    TS(diag_tsnd,c->mytid);
    diag_tsnd_fin = diag_tsnd;

    // Process packet we should send

    if(c->pktstat >= 0) {
    
        // Optionally send packet. 
        // For last-hop emulated network routers, we just need the logs
    
        if (!oarg->nosend) {
            int n;
    
            // Update e_delay in packet with time in dbf queue
    	
            nets = htons(e_delay + qdelay);
            bufp = c->pktbuf + PKTIDLEN + sizeof (struct in_addr);
            memcpy(bufp, &nets, sizeof(uint16_t));
    
            n = sendto(c->sockfd, c->pktbuf, CLNT_MSGLEN, MSG_DONTWAIT,
                           (struct sockaddr *) NULL, 0);
    
            if ((n != CLNT_MSGLEN) && (errno != ECONNREFUSED)) {
                fprintf(stderr, "%lu: sendto problem: %d:%d!\n", c->mytid, n, errno);
                free(c->pktbuf);
                close(c->sockfd);
                // return(NULL);
                exit(-1);
            }
            TS(diag_tsnd_fin,c->mytid);
        }
    
        // tdqdmin: minimum (oldest) timestamp for which we still dequeue.
	// any packets that can only be sent before tdqmin will be considered
	// expired. Update tdqmin to be after this currently processed packet.
    
        ifbusy_nsec = pktsize * 8 * (1000000000 / IFBITRATE);
        stime_add_ts(&(c->tsend), ifbusy_nsec, &(c->tdqmin));

	// gap: time between end of last send packet and this processed packet

	gap = stime_difftv(&(c->last_tdqmin),&(c->tsend));
	c->last_tdqmin = c->tdqmin;
    
        // diagnostics
	// diag_virt_send_time: virtual time packet has on wire
	// diag_snd_time: real time spent sending the packet
	// p_start, p_end: absolute time from start of program for packet on virtual wire
    
        diag_virt_send_time = ifbusy_nsec / 1000;
        diag_snd_time = stime_difftv(&diag_tsnd, &diag_tsnd_fin);

	p_start = stime_difftv(&(c->t0), &(c->tsend));
	p_end   = stime_difftv(&(c->t0), &(c->tdqmin));

	// When we encounter a linux scheduling issue, we loose CPU. For example a few hundred
	// usec and ten packets. When we get the CPU back, there will be a backlog of these
	// packets. We can still schedule them for correct DBF emulation, but the physical
	// sending time will be late compared to the target emulated sending time.
	
	// Calculate intended emulated send time of packet:
	stime_add_ts(&p_sndtime, (e_delay + qdelay) * 1000, &p_sndtime);

        // calculate how far off the emulated send time is from the
	// actual physical send time (now)
	// diag_tsnd - p_sndtime
	//    - this will be a positive value indicating the amount of time the packet is late.

	t_late = stime_difftv(&p_sndtime, &diag_tsnd);
    
        if (snprintf(logstring, LOGLEN, 
     "%11s sent ed %4u qd %4ld lslo %4ld %4ld gap %4ld stat %d svr %2lu %2lu late %3ld %s\n", 
             c->pktbuf, e_delay, qdelay, lqmin, lqmax,
	     gap, c->pktstat,
             diag_virt_send_time, diag_snd_time, t_late,
             (diag_snd_time > diag_virt_send_time) ? " ETOOLONG" : "") > LOGLEN) {
            fprintf(stderr, "%lu LOG error, exiting\n", c->mytid);
            return NULL;
        }
        evlog(oarg->logs, logstring);
        free(c->pktbuf);
    
    }
    return NULL;
}

void *oif_fn_with_callback(void *oargv)
{
    struct sockaddr_in servaddr;
    struct dequeue_context _c;
    struct dequeue_context *c = &_c;
    struct oif_arg *oarg = (struct oif_arg *) oargv;
    int r;

    c->oargv = oargv;
    c->mytid = pthread_self();
    c->qh = oarg->qhptr;
    c->qh->c = c;

    TSdelay(c->t0,oarg->odelay,c->mytid);
    c->tdqmin = c->last_tdqmin = c->tdqmax = c->t0;

    fprintf(stdout, "OIF thread %lu sending to port %hu\n", c->mytid, oarg->nh_port);

    if (oarg->coreid >= 0)
        if (attach_core(oarg->coreid, c->mytid, "OIF thread"))
            return NULL;

    // Create sending socket
    bzero(&(servaddr), sizeof(servaddr));
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(oarg->nh_port);
    servaddr.sin_family = AF_INET;

    c->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    if (connect(c->sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
        fprintf(stderr, "Error in %lu: Connect Failed \n", c->mytid);
        return NULL;
    }

    while (1) {
	struct timespec tdqmax;

	// Dequeue up to this timestamp (tdqmax)
	// odelay is the amount of time this timestamp will be in the past
	// so that we can ensure packets will not arrive too late when
	// there are linux scheduling issues.

        TSdelay(tdqmax,oarg->odelay,c->mytid);
        
        // Check if runtime elapsed
        
        if (stime_iselapsed(&(c->t0), &tdqmax, oarg->runtime * 1000000)) {
            fprintf(stdout, "%lu exiting, time up\n", c->mytid);
            close(c->sockfd);
            return NULL;
        }
        
	
        // Attempt to dequeue packet
	// Only grab mutex here so we minimize holding it and therefore
	// do not delay enqueuing into the dbfq

        if (pthread_spin_lock(&(oarg->qhptr->qlock))) {
            fprintf(stderr, "%lu: spinlock problem\n", c->mytid);
            return NULL;
        }
        c->tdqmax = tdqmax; // in critical region so enque thread always reads it correctly.

	// Attempt to dequeue / send another packet unless we are
	// still deserializing one
        r = 0;
        if (!stime_lt(&(c->tdqmax), &(c->tdqmin))) {
            r = pifo_dequeue(c, oif_fn_callback);
        }

        if (pthread_spin_unlock(&(oarg->qhptr->qlock))) {
            fprintf(stderr, "%lu: spinlock problem\n", c->mytid);
            return NULL;
        }
	// Sleeping reduces the amount of getting the spinlock and should therefore
	// help speeding up the enqueuing thread.
	if(!r) {
            usleep(1);
	}
    }
}

int main(int argc, char **argv)
{
    int c;
    int iflg, oflg, fflg, rflg, cflg, xflg, wflg;
    char *saveptr1, *saveptr2, *str1, *token, *subtoken;
    int i, j;
    char expid[EXPIDLEN], fwdid[FWDIDLEN];
    int ierr, uinp;
    int num_iif = 0, num_oif = 0;
    pthread_t iif_threads[MAX_IIF];
    pthread_t oif_threads[MAX_OIF];
    struct pifo_qhead qh[MAX_OIF];
    /* XXX consider linked list to reduce memory waste */
    struct iif_arg iargs[MAX_IIF];
    struct oif_arg oargs[MAX_OIF];
    struct fib fibs[MAX_FIB];
    unsigned short num_fib;
    char addrstr[INET_ADDRSTRLEN];
    unsigned long coreid, core_start, numcores = sysconf(_SC_NPROCESSORS_ONLN);
    unsigned long runtime;

    bzero(expid, EXPIDLEN);
    bzero(fwdid, FWDIDLEN);

    iflg = oflg = fflg = rflg = cflg = xflg = wflg = 0;
    while ((c = getopt(argc, argv, "i:o:f:r:c:x:w:D")) != -1)
    switch (c) {
      /* Input interface parameters */
      case 'i':
        ierr = 0;
        for (j = 0, str1 = optarg; ; j++, str1 = NULL) {
            token = strtok_r(str1, ",", &saveptr1);
            if (token == NULL)
                break;
            subtoken = strtok_r(token, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad input port\n");
                ierr++;
                break;
            }
            iargs[j].port = (unsigned short) uinp;
            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad hdelay\n");
                ierr++;
                break;
            }
            iargs[j].hdelay = (unsigned short) uinp;
        }
        num_iif = j;
        if (!ierr && (num_iif > 0))
            iflg++;
        break;

      /* Output interface parameters */
      case 'o':
        ierr = 0;
        for (j = 0, str1 = optarg; ; j++, str1 = NULL) {
            token = strtok_r(str1, ",", &saveptr1);
            if (token == NULL)
                break;
            subtoken = strtok_r(token, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad oif index\n");
                ierr++;
                break;
            }
            oargs[j].index = (unsigned short) uinp;

            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad oif nexthop port\n");
                ierr++;
                break;
            }
            oargs[j].nh_port = (unsigned short) uinp;

            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad oif delay\n");
                ierr++;
                break;
            }
            oargs[j].odelay = 1000 * (unsigned short) uinp;

            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken) {
                if (strcmp(subtoken, "nosend") == 0) {
                    oargs[j].nosend = 1;
                } else {
                    fprintf(stderr, "oif flag unknown\n");
                    ierr++;
                    break;
                }
            } else {
                oargs[j].nosend = 0;
            }
        }
        num_oif = j;
        if (!ierr && (num_oif > 0))
            oflg++;
        break;

      /* FIB parameters */
      case 'f':
        ierr = 0;
        for (j = 0, str1 = optarg; ; j++, str1 = NULL) {
            token = strtok_r(str1, ",", &saveptr1);
            if (token == NULL)
                break;
            subtoken = strtok_r(token, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            if (inet_pton(AF_INET, subtoken, &fibs[j].dest_addr) != 1) {
                fprintf(stderr, "Bad ipv4 dest addr\n");
                ierr++;
                break;
            }
            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad fib oif index\n");
                ierr++;
                break;
            }
            fibs[j].oif_index = (unsigned short) uinp;
            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp)) {
                fprintf(stderr, "bad todelay\n");
                ierr++;
                break;
            }
            fibs[j].todelay = (unsigned short) uinp;
            subtoken = strtok_r(NULL, ":", &saveptr2);
            if (subtoken == NULL) {
                ierr++;
                break;
            }
            uinp = atoi(subtoken);
            if (!good_short(uinp) || (uinp == 0)) {
                fprintf(stderr, "bad tohops\n");
                ierr++;
                break;
            }
            fibs[j].tohops = (unsigned short) uinp;
        }
        num_fib = j;
        if (!ierr && (num_fib > 0))
            fflg++;
        break;

      /* Runtime */
      case 'r':
        uinp = atoi(optarg);
        if ((uinp < 0) || (uinp > 100)) {
            fprintf(stderr, "bad runtime\n");
            exit(1);
        }
        runtime = (unsigned long) uinp;
        rflg++;
        break;

      // input string (experiment id)
      case 'x':
        strncpy(expid, optarg, EXPIDLEN - 1);
        xflg++;
        break;

      // input string (fwd id)
      case 'w':
        strncpy(fwdid, optarg, FWDIDLEN - 1);
        wflg++;
        break;

      /* CPU set information
       * Accept the starting core id for the block of cores this fwd should use.
       * Every oif and iif will attach to a distinct core from this block.
       */
      case 'c':
        uinp = atoi(optarg);
        if ((uinp < 0) || (uinp > (numcores - 1))) {
            fprintf(stderr, "bad starting core-id\n");
            exit(1);
        }
        core_start = uinp;
        cflg++;
        break;

      default:
        usage();
        exit(1);
    }

    if (!iflg || !oflg || !fflg || !rflg || !xflg || !wflg) {
        fprintf(stderr, "required flags not specified\n");
        usage();
        exit(1);
    }

    for (i = 0; i < num_fib; i++) {
        int oif_found = 0;
        for (j = 0; j < num_oif; j++) {
            if (fibs[i].oif_index == oargs[j].index) {
                fibs[i].nh_port = oargs[j].nh_port;
                oif_found++;
                break;
            }
        }
        if (!oif_found) {
            fprintf(stderr, "oif index %hu missing\n", fibs[i].oif_index);
            exit(1);
        }
    }

    printf("EXP %s FWD %s\n", expid, fwdid);
    printf("input if config:\n");
    for (i = 0; i < num_iif; i++)
        printf("port: %hu, hdelay %hu\n", iargs[i].port, iargs[i].hdelay);

    printf("output if config:\n");
    for (i = 0; i < num_oif; i++)
        printf("index %hu, nh-port: %hu, odelay: %hu %s\n", oargs[i].index,
               oargs[i].nh_port, oargs[i].odelay, oargs[i].nosend ? ", nosend" : "");
    printf("fibs\n");
    for (i = 0; i < num_fib; i++) {
        if (!inet_ntop(AF_INET, &fibs[i].dest_addr, addrstr, INET_ADDRSTRLEN)) {
            fprintf(stderr, "Problem converting fib dest addr\n");
            exit(1);
        }
        printf("dest ip %s nh-port %hu todelay %hu tohops %hu\n",
               addrstr, fibs[i].nh_port, fibs[i].todelay, fibs[i].tohops);
    }
    if (cflg)
        printf("starting core id for core id block %lu\n", core_start);

    printf("runtime %lu\n", runtime);

    char logname[64];

    // Initiate oif qheaders and oif thread arguments and start threads
    for (i = 0; i < num_oif; i++) {
        char *mybuf;
        int r;

        sprintf(logname, "./UDPFWD-%s-%s-OIF-%d", expid, fwdid,
                oargs[i].index);
        FILE *logstream = fopen(logname, "w");

        if (logstream == NULL) {
            fprintf(stderr, "cannot open oif log\n");
            exit(1);
        }

#define G1 (1024 * 1024 * 128)

        mybuf = (char *) malloc (G1);
        if (mybuf == NULL) {
            fprintf(stderr, "cannot malloc %d buffer\n", G1);
            exit(1);
        }
        r = setvbuf(logstream, mybuf, _IOFBF, G1);
        if (r) {
            fprintf(stderr, "cannot setvbuf (%d)\n", errno);
            exit(1);
        }

        oargs[i].logs = logstream;
        oargs[i].runtime = runtime;
        if (cflg)
            oargs[i].coreid = (core_start + i * 2) % numcores;
        else
            oargs[i].coreid = -1;

        //if (pthread_mutex_init(&qh[i].qlock, NULL) != 0) {
        if (pthread_spin_init(&qh[i].qlock, PTHREAD_PROCESS_PRIVATE) != 0) {
            fprintf(stderr, "lock init has failed\n");
            exit(1);
        }
        pifo_init_qh(&qh[i]);
        oargs[i].qhptr = &qh[i];
        // if (pthread_create(&oif_threads[i], NULL, oif_fn, &oargs[i])) {
        if (pthread_create(&oif_threads[i], NULL, oif_fn_with_callback, &oargs[i])) {
            fprintf(stderr, "thread create error\n");
        }
        printf("OIF thread %d logging to %s\n", i, logname);
    }

    // Initiate iif thread arguments and start threads
    for (i = 0; i < num_iif; i++) {
        char *mybuf;
        int r;

        sprintf(logname, "./UDPFWD-%s-%s-IIF-%d", expid, fwdid,
                iargs[i].port);
        FILE *logstream = fopen(logname, "w");
        if (logstream == NULL) {
            fprintf(stderr, "cannot open iif log\n");
            exit(1);
        }

        mybuf = (char *) malloc (G1);
        if (mybuf == NULL) {
            fprintf(stderr, "cannot malloc %d buffer\n", G1);
            exit(1);
        }
        r = setvbuf(logstream, mybuf, _IOFBF, G1);
        if (r) {
            fprintf(stderr, "cannot setvbuf (%d)\n", errno);
            exit(1);
        }

        iargs[i].logs = logstream;
        iargs[i].runtime = runtime;
        iargs[i].num_fib = num_fib;
        iargs[i].fibptr = &fibs[0];
        iargs[i].qhptr = &qh[0];
        if (cflg)
            iargs[i].coreid = (core_start + (num_oif + i) * 2) % numcores;
        else
            iargs[i].coreid = -1;

        if (pthread_create(&iif_threads[i], NULL, iif_fn, &iargs[i])) {
            fprintf(stderr, "thread create error\n");
        }
        printf("IIF thread for port %hu logging to %s\n", iargs[i].port,
               logname);
    }

    for (i = 0; i < num_iif; i++) {
        if (pthread_join(iif_threads[i], NULL)) {
            fprintf(stderr, "Error joining thread\n");
        }
        (void) fclose(iargs[i].logs);
    }
    for (i = 0; i < num_oif; i++) {
        if (pthread_join(oif_threads[i], NULL)) {
            fprintf(stderr, "Error joining thread\n");
        }
        (void) fclose(oargs[i].logs);
    }
}
